# Devin Issue Triage Agent

> **Cognition Take-home submission** — autonomously triages and resolves GitHub issues using the Devin v3 API.
>
> **Loom recording**: [link to be added]
>
> Built for "FinServ Co" — issues piling up in different types, senior engineers focused on platform work, juniors slowed by triage. This system gets the stuck process moving — automatically.

---

## What it does

1. Engineer adds a `devin-triage` label to a GitHub issue
2. GitHub Actions fires `issues.labeled` and dispatches to Devin
3. Devin runs autonomously, configured with our team's Playbook + Knowledge Notes + Snapshot
4. Devin returns one of three outcomes:
   - 🟢 `pr_opened` — safe and easy to fix → opens PR
   - 🟡 `skipped_unsafe` — sensitive area → comments and escalates to a human
   - 🔴 `aborted_too_complex` — too complex → surfaces for design judgment
5. Streamlit dashboard shows real-time metrics for executives, engineers, and project managers

**No human intervention** from issue label to PR.

---

## Architecture

```
[GitHub Issue + devin-triage label]
    ↓
[GitHub Actions: .github/workflows/devin-triage.yml]
    ↓ orchestrator.py is called
[Devin v3 API: POST /sessions]
  - playbook_id: Issue Auto-Fix
  - knowledge_ids: Coding Standards / PR Conventions / Safe-Change Heuristics
  - structured_output_schema: { can_auto_fix, action_taken, ... }
  - Snapshot Setup: pre-cloned repo
    ↓
[Devin Session — autonomous, fully on its own]
  ├─ Reads issue, applies playbook, references knowledge
  ├─ If safe → modifies code → opens PR
  └─ If unsafe → comments and escalates
    ↓
[Pull Request → Engineer review]
[Structured output → Streamlit Dashboard]
```

See `architecture.md` for detailed diagrams.

---

## Quick start

```bash
git clone <this-repo>
cd <repo>
cp .env.example .env
# Edit .env with your DEVIN_API_KEY and DEVIN_ORG_ID

# Run with Docker Compose
docker compose up dashboard       # dashboard at http://localhost:8501
docker compose run --rm tests     # run pytest suite
```

Or run with Python directly:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run dashboard.py
```

---

## Live demo flow

After setup, trigger 3 demo issues:

```bash
# Load env first (the script uses GITHUB_TOKEN directly via the GitHub API)
set -a && source .env && set +a

./scripts/create_demo_issues.sh
```

This creates 3 issues of different complexity:
- A safe one (docstring addition) → expect `pr_opened`
- A sensitive one (password hashing in security/) → expect `skipped_unsafe`
- A complex one (200+ file async migration) → expect `aborted_too_complex`

Watch the GitHub Actions workflow fire, Devin sessions spin up, and the dashboard update in real time.

To clean up between demo runs:
```bash
./scripts/create_demo_issues.sh --reset      # Closes all open devin-triage issues
./scripts/create_demo_issues.sh --reset --create   # Reset + fresh run
```

---

## Repository structure

```
.
├── README.md                       # This file
├── architecture.md                 # System diagrams (4 levels of detail)
├── slides.html                     # Presentation slides (open in browser)
├── orchestrator.py                 # Main: GitHub event → Devin session
├── dashboard.py                    # Streamlit dashboard (3 audiences: exec/eng/PM)
├── requirements.txt                # Python dependencies
├── Dockerfile                      # Container image
├── docker-compose.yml              # dashboard / tests / cli profiles
├── .env.example                    # Environment variable template
├── .gitignore
├── .github/workflows/
│   └── devin-triage.yml            # GitHub Actions workflow (issues.labeled trigger)
├── scripts/
│   ├── create_playbooks.py         # Provisions the Issue Auto-Fix playbook
│   ├── create_knowledge.py         # Provisions 3 knowledge notes
│   ├── create_demo_issues.sh       # CLI helper to create 3 demo issues
│   └── demo-issues/                # Issue body templates
│       ├── issue-1-safe.md
│       ├── issue-2-unsafe.md
│       └── issue-3-complex.md
└── tests/
    ├── test_orchestrator.py        # Unit tests (9 cases, all passing)
    └── test_dispatch.py            # Integration test (requires GITHUB_TOKEN)
```

---

## Devin configuration (org-level)

This system relies on three Devin resources that are configured **once** and reused across all sessions:

### 1. Playbook: "Issue Auto-Fix"
The triage procedure — what to do, in what order. Versioned on Devin's side.

### 2. Knowledge Notes (×3)

| Note | Trigger | Purpose |
|---|---|---|
| Superset Coding Standards | Writing Python code | Apply project conventions |
| PR and Commit Conventions | Creating a PR | Conventional Commits, structure |
| Safe-Change Heuristics | Deciding to auto-fix | Refuse if security/auth/migration files |

### 3. Snapshot Setup
Pre-cloned repository with Python environment. Sessions boot in seconds, no `git clone` overhead.

Run `scripts/create_playbooks.py` and `scripts/create_knowledge.py` to provision these in your Devin organization.

---

## Tests

```bash
pytest -v tests/                    # Local
docker compose run --rm tests       # In Docker
```

- 9 unit tests in `test_orchestrator.py` — schema, dispatch logic, error handling
- Integration test in `test_dispatch.py` — requires `GITHUB_TOKEN` and `DEVIN_API_KEY`

---

## Observability

The Streamlit dashboard answers: **"How do I know it's working?"** for three audiences:

| Audience | What they see |
|---|---|
| **Executives** | Engineer-hours saved, total cost, MTTR, ROI |
| **Engineers** | Auto-fix rate, throughput, recent sessions, decision reasoning |
| **Project managers** | Trend over time, distribution by category/complexity |

Every session emits a structured JSON output with `action_taken`, `reasoning`, `files_changed`, etc. Every decision is auditable — there is no black box.

---

## Why this architecture

| Capability | Why |
|---|---|
| **Playbook** | Triage procedure is versioned and reusable across sessions, not duplicated per prompt |
| **Knowledge Notes** | Org rules apply automatically when triggers match — no prompt rewriting |
| **Snapshot Setup** | Sessions boot in seconds, not minutes |
| **structured_output_schema** | JSON-validated, auditable — every decision feeds the dashboard |
| **GitHub Actions trigger** | Native integration; no infrastructure to maintain |

The architecture is built for evolution: update the Playbook, every future session benefits. Add a Knowledge Note, Devin picks it up automatically. Pin a new Snapshot, sessions get the new environment.

---

## Roadmap proposal

| Phase | Duration | Goal |
|---|---|---|
| **1: Pilot** | 2 weeks | Run a few dozen real issues; measure auto-fix rate, merge rate, engineer time saved |
| **2: CI/CD integration** | 1 month | Wire Devin into existing CI/CD pipeline; trigger from CodeQL, flaky test failures, dependency updates |
| **3: Production deployment** | Ongoing | Devin becomes a permanent part of the engineering workflow |

---

## Author

[Tatsuya Nakamura](https://www.linkedin.com/in/tatsuyanakamura/) — submitted as part of the Cognition Deployed Engineering interview process.
