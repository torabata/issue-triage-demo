Convert all synchronous SQLAlchemy queries throughout the codebase to async style using SQLAlchemy 2.0 async session management. Estimated 200+ files affected including models, DAOs, and tests.

## Scope

- Convert all model query methods to async
- Update all DAO/repository layers
- Update all tests to use async fixtures
- Update documentation

## Acceptance criteria

- All endpoints continue to work after migration
- Test suite passes
- No regressions in any existing functionality
- Performance benchmarks documented
